- <h1 align="center">📱 WELCOME TO MY GITHUB 👋</h1>
![IMG_20220320_184923_554](https://telegra.ph/file/c0cd501fd8efe8fc25eeb.jpg)

<p align="center">
  <a href="https://ibb.co/QQX130c"><img src="http://readme-typing-svg.herokuapp.com?color=1C71FA&center=true&vCenter=true&multiline=false&lines=Salam+One+Heart+😍+From+Indonesia.;I'am+Not+Programmer." alt="Maxxy Botz">

</p>
<h1 align="center">🎧 Kahfi-XD</h1>
<p align="center">
  <a href="https://github.com/Kahfi-XD"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=Hello+Guys!+Im+owner+Maxxy+Bot;My+Name+is+🎧 Kahfi+Bot;Learning+JavaScript!;Please+Support+Me+With+Donate;Thanks🥰" alt="UwU">
</p>

<p align="center">
<a href="https://github.com/Kahfi-XD"><img title="Author" src="https://img.shields.io/badge/Kahfi-Ofc-blue.svg?style=for-the-badge&logo=github"></a>
 </p>
 <h4 align="center">
  <a
  <a href="https://wa.me/6285380166282">If there is a need, you can directly chat with me </a>
</h4>
</p>


## ```📱 ABOUT ME```
```bash
- 👋 Hello, I’m @Kahfi-XD
- 👀 I’m interested in the media
- 🌱 I'm just a beginner in this field
- 💞️ I don't care what people say about me, I just want to give this a try
- 📫 I'am not a developer, I'm not a mastah and I'm not a temperature
```

## ```📱 FOLLOW SOSIAL MEDIA ME```
<p align="center">
<a href="https://instagram.com/Kahfixd01"><img src="https://img.shields.io/badge/INSTAGRAM-E4405F?style=for-the-badge&logo=instagram&logoColor=white"/> 
<a href="https://wa.me/6285380166282"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://youtube.com/channel/UC6GPl9xMWL61NAXQb3HBrRw"><img src="https://img.shields.io/badge/YOUTUBE KAHFI OFFICIAL-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtube.com/c/hokenbeusz" /><br>
<a href="https://www.tiktok.com/@kahfifttiktok"><img src="https://img.shields.io/badge/TIKTOK-black?style=for-the-badge&logo=tiktok&logoColor=ff000000&link=https://tiktok.com/@unfaedahkan" /></a>
</p>

## ```📱 SUPPORT DENGAN CARA DONASI```

- [`DANA`](https://wa.me/6285380166282?text=banh+ini+nomor+nya+kah+085380166282+?)
- [`PULSA`](https://wa.me/6285380166282?text=banh+ini+nomor+nya+kah+085380166282+?)
> Jika ingin berdonasi lewat link
> Klik [ SAWERIA ](https://saweria.co/kahfiaja)

## ```📱 GROUP BOT```

- [`GROUP WA BOT¹`](https://chat.whatsapp.com/K6femuL8bLx6HqWS7wXofI)
- [`GROUP WA BOT²`](https://chat.whatsapp.com/CcfG9mg5Vxc9vdV6RfwVmc)
  
## ```📱 WHATSAPP KAHFI OFFICIAL```
  CHAT SAYA JIKA ANDA INGIN MENANYAKAN SESUATU🚀
- [`WHATSAPP KAHFI OFFICIAL`](https://wa.me/6285380166282?text=Assalamualaikum+Banh+KAHFI+OFFICIAL)

## ```📮 CREATOR BOT```
 [![Kahfi Official](https://github.com/Kahfi-XD.png?size=200)](https://github.com/Kahfi-XD) 
---->
[Kahfi-XD](https://github.com/kahfi-XD) 
 CREATOR
  
## ```📮 KAHFI-XD STATISTICS```

[![KrizynOfc GitHub Stats](https://github-readme-stats.vercel.app/api?username=Kahfi-XD&show_icons=true&hide=issues&theme=radical)](https://github-readme-stats.vercel.app)
[![KrizynOfc Top Languages](https://github-readme-stats.vercel.app/api/top-langs?username=Kahfi-XD&layout=compact&theme=radical)](https://github-readme-stats.vercel.app)

  ## ```📮 KAHFI-XD STATUS```
  
 <details>
    <summary>&#127942 <b>GitHub Awards</b></summary><br/>

![Github Trophy](https://github-profile-trophy.vercel.app/?username=KrizynOfc)

</details>

<details>
    <summary>&#127942 <b>GitHub Activity</b></summary><br/>

![Metrics](https://metrics.lecoq.io/krizynOfc template=classic&repositories.forks=true&languages=1&languages.colors=github&languages.threshold=0%25&config.timezone=Asia%2FJakarta)

</details> 

![github stats](https://github-readme-stats.vercel.app/api?username=Kahfiofc&show_icons=true)
<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=kahfiofc&theme=vue">


## ```📮 AUTHOR```
 
  [KAHFI-XD](https://github.com/Kahfi-XD)
 AUTHOR

<!---
I LOVE YOU GUYS
--->
